#include "directories_list.h"

int main(int argc, char* argv[]) {

    chdir(argv[1]); //changes current dir to folder specified in first argument
    directories_open(argv[1]);
    directories_list();
    directories_close();

    return 0;
}