//
// Created by Tommay on 21.09.2017.
//

#include "directories_list.h"
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>


BOOL directories_open(char *pDir) {     //opens file pointer on given directory
    dirPointer = opendir(pDir); //file pointer points at given directory
    if (dirPointer != NULL) {   //if directory can be opened
        return true;
    } else
        return false;
}

BOOL directories_list() {   //lists content of directory which file pointer points to
    struct stat statStructure;  //creates stat structure containing directory attributes

    while (dirStruct = readdir(dirPointer)) {   //points file pointer at each file in directory

        stat(dirStruct->d_name, &statStructure);    //points file pointer at next file in directory
        if (dirStruct->d_type == DT_DIR     //only prints name and size if current file is a directory
            && strcmp(".", dirStruct->d_name) != 0  //and if its name is not "."
            && strcmp("..", dirStruct->d_name) != 0) {  //and if its name is not ".."
            printf("%s (%ld)\n", dirStruct->d_name, statStructure.st_size); //prints file name and size of directory
        }
    }

    if (dirStruct == 0) //if file pointer pointed at each file in directory
        return true;
    else {
        perror("Error");
        return false;
    }
}

BOOL directories_close() {  //closes file pointer directory
    //dirPointer = closedir(dirPointer);
    if (closedir(dirPointer) == 0)
        return true;
    else {
        perror("Error");
        return false;
    }
}

