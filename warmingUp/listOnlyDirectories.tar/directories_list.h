//
// Created by Tommay on 21.09.2017.
//
#ifndef WARMING_UP_DIRECTORIES_LIST_H
#define WARMING_UP_DIRECTORIES_LIST_H

#include <dirent.h>


DIR *dirPointer;
struct dirent *dirStruct;
typedef enum {false, true} BOOL;

BOOL directories_open(char *pDir);

BOOL directories_list();

BOOL directories_close();

#endif //WARMING_UP_DIRECTORIES_LIST_H
