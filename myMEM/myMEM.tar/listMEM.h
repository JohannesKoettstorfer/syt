#ifndef __GET_MEM
#define __GET_MEM

// TYPEDEF
typedef enum {false, true} bool;

bool mem_openFile(char *fName);
bool mem_closeFile();
bool mem_print();
#endif
